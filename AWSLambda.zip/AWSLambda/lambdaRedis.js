'use strict';
var redis = require("redis");
// var awsIot = require('aws-iot-device-sdk');
// var AWS = require('aws-sdk'); 

console.log('Loading Function');

exports.handler = function(event, context, callback) {
    console.log('Recieved Event Data.now:', timeStampValue);
    console.log('Recieved Events:', JSON.stringify(event, null, 2));
    console.log('output :', event.data);
    console.log('output Event :', event);

    
    var client = redis.createClient("redis:// tcg-elasticcache-002.4pjfbh.0001.euw1.cache.amazonaws.com:6379");
    multi = client.multi();
    //var date = Date.now();

    multi.publish("Warnings", 
                            "<font color='Blue'>  RPM:" + event.data.Proximity_Hack_Predix_TAE.RPM + "</font>" +
                            " awsRequestId:" + context.awsRequestId 	+ 
                            " timestamp:" + event.data.Proximity_Hack_Predix_TAE.TIMESTAMP );


    multi.zadd("data", date, event.data); 
    multi.hmset(event.data,
                            "RPM", event.data.Proximity_Hack_Predix_TAE.RPM , 
                            "timestamp", event.data.Proximity_Hack_Predix_TAE.TIMESTAMP,
                            "awsRequestId", context.awsRequestId);   

    multi.exec(function (err, replies) {

      if (err) {
			
       console.log('error updating event: ' + err);
			 context.fail('error updating event: ' + err);
       
		  } else {
      
			 console.log('updated event ' + replies);
			 context.succeed(replies); 
       client.quit();             
		  
      }   
                     
 });

    // //context.done(null, 'Hello from Lambda');
    // console.log('Recieved events:', JSON.stringify(event, null, 2));
    // console.log('output :', event.data);
    // console.log('output Event :', event);
    // //console.log('value =', event.key);
    // callback(null, event.key); //echo back the first key value
    // //callback('Something went wrong')
};